package com.example.projecttwo_michellepowers;

// Class used to store individual events and retrieve/edit their data.
public class EventHelper {
    public String eventID;
    private String eventName;
    private String eventDate;
    private String eventTime;

    public EventHelper(String eventID, String eventName, String eventDate, String eventTime) {
        this.eventID   = eventID;
        this.eventName = eventName;
        this.eventDate = eventDate;
        this.eventTime = eventTime;
    }

    public String getEventName() {
        return eventName;
    }
    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventDate() {
        return eventDate;
    }
    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }

    public String getEventTime() {
        return eventTime;
    }
    public void setEventTime(String eventTime) {
        this.eventTime = eventTime;
    }

    public String getEventID() {
        return eventID;
    }
    public void setEventID(String eventID) {
        this.eventID = eventID;
    }
}
