package com.example.projecttwo_michellepowers;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class EventDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "Event.db";
    private static final String COL_2 = "NAME";
    private static final String COL_3 = "DATE";
    private static final String COL_4 = "TIME";

    // Create a new unique database shell for each user, using their username as part of the DB name.
    // Example: "user1.Event.db"
    public EventDatabaseHelper(Context context, String username) {
        super(context, username + "." + DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE Events (ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, DATE TEXT, TIME TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Events");
        onCreate(db);
    }

    // Inserts a new event.
    public void insertData (String name, String date, String time) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2, name);
        contentValues.put(COL_3, date);
        contentValues.put(COL_4, time);
        db.insert("Events", null, contentValues);
    }

    // Reads all events, and stores them in an array.
    public ArrayList<EventHelper> readAllData() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + "Events", null);

        ArrayList<EventHelper> eventHelperArrayList = new ArrayList<>();

        if (cursor.moveToFirst()) {
            do {
                eventHelperArrayList.add(new EventHelper(cursor.getString(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3)));
            } while (cursor.moveToNext());
        }

        cursor.close();
        return eventHelperArrayList;
    }

    // Find and delete an event based on its ID.
    public void deleteData (String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("Events", "id=?", new String[]{id});
    }

    // Find and update an event based on its ID.
    public void updateData (String id, String name, String date, String time) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2, name);
        contentValues.put(COL_3, date);
        contentValues.put(COL_4, time);
        db.update("Events", contentValues, "id=?", new String[]{id});
    }
}
