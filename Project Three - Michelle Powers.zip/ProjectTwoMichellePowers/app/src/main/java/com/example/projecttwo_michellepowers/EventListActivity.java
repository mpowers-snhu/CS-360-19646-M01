package com.example.projecttwo_michellepowers;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.GridView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class EventListActivity extends AppCompatActivity {
    GridView eventGrid;
    EventDatabaseHelper eventDatabaseHelper;
    String dbUser;
    ArrayList <String> selectedEvents = new ArrayList<>();
    Button removeEvent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        // Get the database shell username prefix.
        Bundle user = getIntent().getExtras();
        if (user != null) {
            dbUser = user.getString("user");
        }

        // Store Views
        eventGrid = findViewById(R.id.gridEvents);
        removeEvent = findViewById(R.id.buttonRemoveEvent);
        eventDatabaseHelper = new EventDatabaseHelper(this, dbUser);

        refreshEventList();
    }

    // Refreshes the GridView adapter using new database data.
    public void refreshEventList () {
        ArrayList<EventHelper> eventHelperArrayList = eventDatabaseHelper.readAllData();
        EventAdapter adapter = new EventAdapter(this, eventHelperArrayList, dbUser);
        eventGrid.setAdapter(adapter);
    }

    // OnClick function called when a user clicks on an individual event's CheckBox.
    public void eventSelected(View view) {
        CheckBox eventChecked = (CheckBox) view;
        String id = (String) eventChecked.getTooltipText(); // "Hidden" value used to store event IDs in the grid.

        // Maintain a list of all IDs the user has selected; remove any that are unselected.
        if (eventChecked.isChecked()) {
            selectedEvents.add(id);
        }
        else if (!eventChecked.isChecked()) {
            if (id != null)
                selectedEvents.removeIf(id::equals);
        }

        // Enable the remove button if > 0 events are selected
        if (!selectedEvents.isEmpty())
            removeEvent.setEnabled(true);
        else removeEvent.setEnabled(false); // Otherwise, disable
    }

    // Move to the "Add Event" activity.
    public void addEvent(View view) {
        Intent i = new Intent(EventListActivity.this, AddEventActivity.class);
        i.putExtra("user", dbUser);
        startActivity(i);
    }

    // Uses our list of selected events to remove them from both the database and grid.
    public void removeEvent(View view) {
        for (String id : selectedEvents) {
            eventDatabaseHelper.deleteData(id);
        }

        // Clear selection list, disbale the remove button, and refresh the event grid.
        selectedEvents.clear();
        removeEvent.setEnabled(false);
        refreshEventList();
    }

    // Logout button handler - move back to the login screen if it's pressed.
    public void logout(View view) {

        Intent i = new Intent(EventListActivity.this, LoginActivity.class);
        startActivity(i);
    }
}