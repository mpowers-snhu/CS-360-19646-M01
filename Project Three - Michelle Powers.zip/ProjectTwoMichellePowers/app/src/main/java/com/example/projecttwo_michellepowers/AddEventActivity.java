package com.example.projecttwo_michellepowers;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class AddEventActivity extends AppCompatActivity implements TextWatcher {

    EditText name, date, time;
    Button addButton;
    String dbUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        // Get the database shell username prefix.
        Bundle user = getIntent().getExtras();
        if (user != null) {
            dbUser = user.getString("user");
        }

        // Store Views
        name = findViewById(R.id.textEventName);
        date = findViewById(R.id.textEventDate);
        time = findViewById(R.id.textEventTime);
        addButton = findViewById(R.id.buttonAdd);

        // Enable the add button, and set up the empty textbox check for the three fields.
        addButton.setEnabled(false);
        name.addTextChangedListener(this);
        date.addTextChangedListener(this);
        time.addTextChangedListener(this);
    }

    public void add(View view) {
        // Insert the user-entered event data into the database.
        EventDatabaseHelper eventDatabaseHelper = new EventDatabaseHelper(this, dbUser);
        eventDatabaseHelper.insertData(name.getText().toString(), date.getText().toString(), time.getText().toString());

        // Check if the app has permission to send SMS
        // If so, send details of the new event to this phone (5037 is the port/phone number of this emulator)
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("5037", null, "******* M2A Planner Reminder *******\nEvent '"
                            + name.getText().toString()
                            + "' scheduled for "
                            + date.getText().toString() + " at "
                            + time.getText().toString() + ".",
                    null, null);
        }

        // Move back to the event list screen
        Intent i = new Intent(AddEventActivity.this, EventListActivity.class);
        i.putExtra("user", dbUser);
        startActivity(i);
    }

    // Move back to the event list screen
    public void cancel(View view) {
        Intent i = new Intent(AddEventActivity.this, EventListActivity.class);
        i.putExtra("user", dbUser);
        startActivity(i);
    }

    // Checks whether any of the event fields are empty and enables/disables the add button appropriately
    @Override
    public void afterTextChanged(Editable s) {
        if (name.getText().toString().isEmpty() || date.getText().toString().isEmpty()
        || time.getText().toString().isEmpty())
            addButton.setEnabled(false);
        else addButton.setEnabled(true);
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }
}