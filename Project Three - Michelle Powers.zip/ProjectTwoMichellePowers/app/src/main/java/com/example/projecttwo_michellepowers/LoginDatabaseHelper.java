package com.example.projecttwo_michellepowers;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class LoginDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "Login.db";
    private static final String COL_2 = "USERNAME";
    private static final String COL_3 = "PASSWORD";

    public LoginDatabaseHelper(Context context) { super(context, DATABASE_NAME, null, 1);}

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE Users (ID INTEGER PRIMARY KEY AUTOINCREMENT, USERNAME TEXT, PASSWORD TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Users");
        onCreate(db);
    }

    public boolean insertData (String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2, username);
        contentValues.put(COL_3, password);
        long result = db.insert("Users", null, contentValues);
        return result != -1;
    }

    // Checks both the username and password.
    // Returns true if the information is correct, or false if not.
    public Boolean checkLogin (String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        String[] columns = {COL_2};
        String selection = "USERNAME=? AND PASSWORD=?";
        String selectionArgs[] = {username, password};
        Cursor cursor = db.query("Users", columns, selection, selectionArgs, null, null, null);

        if (cursor != null && cursor.moveToFirst())
        {
            return true;
        }

        return false;
    }

    // Checks the username only; used for account creation.
    // Returns true if it exists, or false if not.
    public Boolean checkUserExists (String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        String[] columns = {COL_2};
        String selection = "USERNAME=?";
        String selectionArgs[] = {username};
        Cursor cursor = db.query("Users", columns, selection, selectionArgs, null, null, null);

        if (cursor != null && cursor.moveToFirst())
        {
            return true;
        }

        return false;
    }
}
