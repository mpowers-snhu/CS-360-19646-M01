package com.example.projecttwo_michellepowers;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class LoginActivity extends AppCompatActivity implements TextWatcher {

    EditText username, password;
    Button loginButton;
    CheckBox newUser;
    LoginDatabaseHelper loginDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);

        // Get view data
        username = findViewById(R.id.textUsername);
        password = findViewById(R.id.textPassword);
        newUser = findViewById(R.id.checkNewuser);
        loginButton = findViewById(R.id.buttonLogin);

        // Create the login database
        loginDatabaseHelper = new LoginDatabaseHelper(this);

        loginButton.setEnabled(false);
        username.addTextChangedListener(this);
        password.addTextChangedListener(this);
    }

    // This function is not used, but is needed to compile and run the app
    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    // This function is not used, but is needed to compile and run the app
    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    // Checks if the username of passwords fields are empty, so we can enable or disable the login button
    @Override
    public void afterTextChanged(Editable s) {
        if (username.getText().toString().isEmpty() || password.getText().toString().isEmpty())
            loginButton.setEnabled(false);
        else loginButton.setEnabled(true);
    }

    // Switches the screen from 'login' -> 'permissions'
    public void logIn(View view) {

        String dbUser = username.getText().toString().trim();
        String dbPass = password.getText().toString().trim();
        Boolean userExists;

        // Check the database for the user's entered information.
        userExists = loginDatabaseHelper.checkLogin(dbUser, dbPass);

        // Account information is incorrect - let the user know.
        if (!userExists && !newUser.isChecked()) {
            Toast.makeText(LoginActivity.this, "Username or password incorrect. Check 'New user' to register a new account.", Toast.LENGTH_SHORT).show();
        }
        // New user - create a new account.
        else if (newUser.isChecked())
        {
            // Check whether the user already exists before making a new account.
            if (loginDatabaseHelper.checkUserExists(dbUser)) {
                Toast.makeText(LoginActivity.this, "An account with that username already exists.", Toast.LENGTH_SHORT).show();
            }
            else
            {
                loginDatabaseHelper.insertData(dbUser, dbPass);
                Toast.makeText(LoginActivity.this, "Account created successfully.", Toast.LENGTH_SHORT).show();

                // Move to either the permissions or event list screen, depending on existing permissions.
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    Intent i = new Intent(LoginActivity.this, PermissionActivity.class);
                    i.putExtra("user", dbUser);
                    startActivity(i);
                }
                else {
                    Intent i = new Intent(LoginActivity.this, EventListActivity.class);
                    i.putExtra("user", dbUser);
                    startActivity(i);
                }
            }
        }
        // Existing user; log in.
        else if (userExists && !newUser.isChecked())
        {
            // Move to either the permissions or event list screen, depending on existing permissions.
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                Intent i = new Intent(LoginActivity.this, PermissionActivity.class);
                i.putExtra("user", dbUser);
                startActivity(i);
            }
            else {
                Intent i = new Intent(LoginActivity.this, EventListActivity.class);
                i.putExtra("user", dbUser);
                startActivity(i);
            }
        }
    }
}