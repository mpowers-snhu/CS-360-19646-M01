package com.example.projecttwo_michellepowers;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class EventAdapter extends ArrayAdapter<EventHelper> implements TextWatcher {
    public String dbUser, id, name, date, time;
    View listitemView;
    CheckBox EventID;
    TextView EventName, EventDate, EventTime;

    public EventAdapter(@NonNull Context context, ArrayList<EventHelper> eventModelArrayList, String user) {
        super(context, 0, eventModelArrayList);
        dbUser = user;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        listitemView = convertView;
        if (listitemView == null) {
            // Each row in GridView is inflated from the layout in card_item.xml
            listitemView = LayoutInflater.from(getContext()).inflate(R.layout.card_item, parent, false);
        }

        // Store Views
        EventID   = listitemView.findViewById(R.id.idEventSelected);
        EventName = listitemView.findViewById(R.id.idEventName);
        EventDate = listitemView.findViewById(R.id.idEventDate);
        EventTime = listitemView.findViewById(R.id.idEventTime);

        // Get the event object from our current adapter position.
        EventHelper eventHelper = getItem(position);
        assert eventHelper != null;

        // Store the event object data
        id = eventHelper.getEventID();
        name = eventHelper.getEventName();
        date = eventHelper.getEventDate();
        time = eventHelper.getEventTime();

        // Set the grid view data
        EventID.setTooltipText(id);
        EventName.setText(name);
        EventDate.setText(date);
        EventTime.setText(time);

        // Add text changed listeners, to check for user updates.
        EventName.addTextChangedListener(this);
        EventDate.addTextChangedListener(this);
        EventTime.addTextChangedListener(this);

        // Return the updated row item.
        return listitemView;
    }
    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {
        EventDatabaseHelper eventDatabaseHelper = new EventDatabaseHelper(getContext(), dbUser);

        name = EventName.getText().toString();
        date = EventDate.getText().toString();
        time = EventTime.getText().toString();

        // Checks if any of the row fields are empty; updates all three if not.
        if (!name.isEmpty() && !date.isEmpty() && !time.isEmpty())
            eventDatabaseHelper.updateData(id, name, date, time);
    }
}

