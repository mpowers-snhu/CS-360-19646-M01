package com.example.projecttwo_michellepowers;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view .View;
import android.Manifest;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class PermissionActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_SEND_SMS = 1;
    String dbUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permissions);

        // Get the database shell username prefix.
        Bundle user = getIntent().getExtras();
        if (user != null) {
            dbUser = user.getString("user");
        }
    }


    // Check permissions
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PERMISSION_REQUEST_SEND_SMS: {
                if (permissions[0].equalsIgnoreCase(Manifest.permission.SEND_SMS)
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permission was granted. Move to the main event screen.
                    Intent i = new Intent(PermissionActivity.this, EventListActivity.class);
                    i.putExtra("user", dbUser);
                    startActivity(i);
                } else {
                    // Permission not granted. Let the user know before moving on.
                    Toast.makeText(PermissionActivity.this, "Could not grant SMS permission. Check the app permissions in Android settings.", Toast.LENGTH_LONG).show();
                    Intent i = new Intent(PermissionActivity.this, EventListActivity.class);
                    i.putExtra("user", dbUser);
                    startActivity(i);
                }
            }
        }
    }

    // The user chose "Accept"
    public void permissionAccept (View view) {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_REQUEST_SEND_SMS);
    }

    // The user chose "Decline"
    public void permissionDecline (View view) {
        Intent i = new Intent(PermissionActivity.this, EventListActivity.class);
        i.putExtra("user", dbUser);
        startActivity(i);
    }
}